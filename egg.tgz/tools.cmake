# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(coverity-scan src/coverity-scan.cpp)
set_property(TARGET coverity-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(coverity-scan lionss pthread)

add_executable(heap-profile src/heap-profile.cpp)
set_property(TARGET heap-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(heap-profile lionss pthread)

add_executable(negative-tests src/negative-tests.cpp)
set_property(TARGET negative-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(negative-tests lionss pthread)

add_executable(aur-package src/aur-package.cpp)
set_property(TARGET aur-package PROPERTY CXX_STANDARD 11)
target_link_libraries(aur-package lionss pthread)

add_executable(rdtsc-calibration src/rdtsc-calibration.cpp)
set_property(TARGET rdtsc-calibration PROPERTY CXX_STANDARD 11)
target_link_libraries(rdtsc-calibration lionss pthread)

add_executable(asan src/asan.cpp)
set_property(TARGET asan PROPERTY CXX_STANDARD 11)
target_link_libraries(asan lionss pthread)

add_executable(gcc-oldest src/gcc-oldest.cpp)
set_property(TARGET gcc-oldest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-oldest lionss pthread)

add_executable(llvm-libcxx src/llvm-libcxx.cpp)
set_property(TARGET llvm-libcxx PROPERTY CXX_STANDARD 11)
target_link_libraries(llvm-libcxx lionss pthread)

add_executable(pyinstaller-bundle src/pyinstaller-bundle.cpp)
set_property(TARGET pyinstaller-bundle PROPERTY CXX_STANDARD 11)
target_link_libraries(pyinstaller-bundle lionss pthread)

add_executable(release-dry-run src/release-dry-run.cpp)
set_property(TARGET release-dry-run PROPERTY CXX_STANDARD 11)
target_link_libraries(release-dry-run lionss pthread)

add_executable(vendored-check src/vendored-check.cpp)
set_property(TARGET vendored-check PROPERTY CXX_STANDARD 11)
target_link_libraries(vendored-check lionss pthread)

add_executable(callgrind-profile src/callgrind-profile.cpp)
set_property(TARGET callgrind-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(callgrind-profile lionss pthread)

add_executable(mingw-build src/mingw-build.cpp)
set_property(TARGET mingw-build PROPERTY CXX_STANDARD 11)
target_link_libraries(mingw-build lionss pthread)

add_executable(bazel-build src/bazel-build.cpp)
set_property(TARGET bazel-build PROPERTY CXX_STANDARD 11)
target_link_libraries(bazel-build lionss pthread)

add_executable(canary-build src/canary-build.cpp)
set_property(TARGET canary-build PROPERTY CXX_STANDARD 11)
target_link_libraries(canary-build lionss pthread)

add_executable(hermetic-build src/hermetic-build.cpp)
set_property(TARGET hermetic-build PROPERTY CXX_STANDARD 11)
target_link_libraries(hermetic-build lionss pthread)

add_executable(lcov-report src/lcov-report.cpp)
set_property(TARGET lcov-report PROPERTY CXX_STANDARD 11)
target_link_libraries(lcov-report lionss pthread)

add_executable(linux-s390x src/linux-s390x.cpp)
set_property(TARGET linux-s390x PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-s390x lionss pthread)

add_executable(pkg-config-check src/pkg-config-check.cpp)
set_property(TARGET pkg-config-check PROPERTY CXX_STANDARD 11)
target_link_libraries(pkg-config-check lionss pthread)

add_executable(release-notes src/release-notes.cpp)
set_property(TARGET release-notes PROPERTY CXX_STANDARD 11)
target_link_libraries(release-notes lionss pthread)

add_executable(oss-fuzz-sync src/oss-fuzz-sync.cpp)
set_property(TARGET oss-fuzz-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(oss-fuzz-sync lionss pthread)

add_executable(gitleaks src/gitleaks.cpp)
set_property(TARGET gitleaks PROPERTY CXX_STANDARD 11)
target_link_libraries(gitleaks lionss pthread)

add_executable(contention-bench src/contention-bench.cpp)
set_property(TARGET contention-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(contention-bench lionss pthread)

add_executable(hardened-runtime src/hardened-runtime.cpp)
set_property(TARGET hardened-runtime PROPERTY CXX_STANDARD 11)
target_link_libraries(hardened-runtime lionss pthread)

add_executable(clang-format-check src/clang-format-check.cpp)
set_property(TARGET clang-format-check PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-format-check lionss pthread)

add_executable(scaling-bench src/scaling-bench.cpp)
set_property(TARGET scaling-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(scaling-bench lionss pthread)

add_executable(cxx20-modules src/cxx20-modules.cpp)
set_property(TARGET cxx20-modules PROPERTY CXX_STANDARD 11)
target_link_libraries(cxx20-modules lionss pthread)

add_executable(package-snap src/package-snap.cpp)
set_property(TARGET package-snap PROPERTY CXX_STANDARD 11)
target_link_libraries(package-snap lionss pthread)

add_executable(thread-sanitizer src/thread-sanitizer.cpp)
set_property(TARGET thread-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(thread-sanitizer lionss pthread)

add_executable(build-header-only src/build-header-only.cpp)
set_property(TARGET build-header-only PROPERTY CXX_STANDARD 11)
target_link_libraries(build-header-only lionss pthread)

