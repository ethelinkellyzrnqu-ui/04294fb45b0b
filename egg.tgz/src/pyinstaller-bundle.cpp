// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("pyinstaller bundle"); }
int main(){
  announce();
  return lionss_run_workload("pyinstaller-bundle");
}
