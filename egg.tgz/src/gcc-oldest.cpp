// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("gcc oldest\n", stdout);
  return lionss_run_workload("gcc-oldest");
}
