// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("hermetic build\n", stdout);
  return lionss_run_workload("hermetic-build");
}
